﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Scores : MonoBehaviour
{
    private int live;
    public Text ScoreText;
    // Start is called before the first frame update
    void Start()
    {
        live = 5;
        ScoreText.text = "Live:" + " " + live;

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            Destroy(other.gameObject);
            live -= 1;
            ScoreText.text = "Live:" + " " + live;
            if (live == 0)
            {
                live = 5;
            }
        }
    }
}
