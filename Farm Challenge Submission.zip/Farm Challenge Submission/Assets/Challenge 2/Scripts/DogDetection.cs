﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class DogDetection : MonoBehaviour
{
    private int Score;
    public Text ScoreText;
    
    void Start()
    {
        Score = 0;
        SetScoreText();

    }

    void OnTriggerEnter(Collider other)
    {
        Destroy(other);
        Score = Score+1;
        SetScoreText();

    }
    void SetScoreText()
    {
        Score = 0;
        ScoreText.text = "Score:" + " " + Score;

    }
}
