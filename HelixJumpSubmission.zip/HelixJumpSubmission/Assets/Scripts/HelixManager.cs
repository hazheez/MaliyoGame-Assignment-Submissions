﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelixManager : MonoBehaviour
{
    public GameObject[] helixRings;
    public float ySpawn = 0;
    public float ringDistance = 5;
    

    public int numberofRings ;

    // Start is called before the first frame update
    void Start()
    {
        numberofRings = GameManager.currentLevelIndex + 9;
       
        for(int i = 0; i < numberofRings; i++)
        {
            if (i == 0)
                spawnRing(0);
            else
                spawnRing(Random.Range(0, helixRings.Length - 1));
        }

        spawnRing (helixRings.Length - 1);


    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void spawnRing(int ringIndex)
    {
        GameObject go = Instantiate(helixRings[ringIndex], transform.up * ySpawn, Quaternion.identity);
        go.transform.parent = transform;
        ySpawn -= ringDistance;
    }
}
