﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public Rigidbody playerRb;
    public float bounceForce = 6.0f;

   
        private void OnCollisionEnter(Collision collision)
    {
        FindObjectOfType<AudioManager>().Play("bounce");
        playerRb.velocity = new Vector3(playerRb.velocity.x, bounceForce, playerRb.velocity.z);
        string materialName = collision.transform.GetComponent<MeshRenderer>().material.name;
        if (materialName == "Safe (Instance)")
        {
            Debug.Log("You score");
        }
        else if (materialName == "Unsafe (Instance)")
        {
            FindObjectOfType<AudioManager>().Play("gameOver");
            GameManager.gameOver = true;
            Debug.Log("Game Over");
        }
        else if (materialName == "Last Ring (Instance)" && !GameManager.levelCompleted)
        {
            FindObjectOfType<AudioManager>().Play("win");
            GameManager.levelCompleted = true;
            Debug.Log("You win");
        }

    }
}
