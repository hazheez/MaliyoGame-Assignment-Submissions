﻿using UnityEngine.SceneManagement;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static int score = 0;
    public Slider gameProgressSlider;
    public static int numberOfPassedRings;
    
    public static bool gameOver;
    public static bool levelCompleted;
    public GameObject GameOverPanel;
    public GameObject levelcompleted;

    public static int currentLevelIndex;
    public TextMeshProUGUI currentLevelText;
    public TextMeshProUGUI nextLevelText;
    public TextMeshProUGUI scoreText;


    private void Awake()
    {
        currentLevelIndex = PlayerPrefs.GetInt("currentLevelIndex", 1);
    }


    // Start is called before the first frame update
    void Start()
    {
        numberOfPassedRings = 0;
        gameOver = levelCompleted = false;
        Time.timeScale = 1;

        currentLevelText.text = "0";
        nextLevelText.text = "1";

    }

    // Update is called once per frame
    void Update()
    {
        scoreText.text = score.ToString();

        currentLevelText.text = currentLevelIndex.ToString();
        nextLevelText.text = (currentLevelIndex+1).ToString();

        int progress = numberOfPassedRings*100/FindObjectOfType<HelixManager>().numberofRings;
        gameProgressSlider.value = progress;
       

        if (gameOver)
        {
            Time.timeScale = 0;
            GameOverPanel.SetActive(true);
            
            if (Input.GetButtonDown("Fire1"))
            {
                score = 0;
                SceneManager.LoadScene(0);
            }
            

        }
        else if (levelCompleted)
        {
            levelcompleted.SetActive(true);
            if (Input.GetButtonDown("Fire1"))
            {
                PlayerPrefs.SetInt("currentLevelIndex", currentLevelIndex+1);

                SceneManager.LoadScene(0);
            }
        }
    }

}
